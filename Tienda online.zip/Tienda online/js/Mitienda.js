var productos = [
  {
    identificación:1,
    nombre: "Lenovo torre PC LOQ3 i5 RTX-4060",
    precio: 600,
    enlace: "https://www.pccomponentes.com/pccom-alurin-amd-ryzen-5-5600g-8gb-500gb-ssd-windows-11-home",
    imagen: "pc1.JPG",
    tipo: "ordenador" 
  },
  {
    identificación:2,
    nombre: "HP Pavilion TP01-4004ns Intel Core i5-13400/16GB/1TB+512GB SSD",
    precio: 400,
    enlace: "https://www.pccomponentes.com/hp-pavilion-tp01-4004ns-intel-core-i5-13400-16gb-1tb-512gb-ssd",
    imagen: "pc3.JPG",
    tipo: "ordenador"
  },
  {
    identificación:3,
    nombre: "HP Slim Desktop S01-pF2027ns Intel Core i5-12400/8GB/256GB SSD",
    precio: 459,
    enlace: "https://www.pccomponentes.com/hp-slim-desktop-s01-pf2027ns-intel-core-i5-12400-8gb-256gb-ssd",
    imagen: "pc4.JPG",
    tipo: "ordenador"
  },
  {
    identificación:4,
    nombre: "HP EliteDesk 800 G5 SFF Intel Core i5-9500/8GB/256GB SSD",
    precio: 400,
    enlace: "https://www.pccomponentes.com/hp-elitedesk-800-g5-sff-intel-core-i5-9500-8gb-256gb-ssd?refurbished",
    imagen: "pc5.JPG",
    tipo: "ordenador"
  },
  {
    identificación:5,
    nombre: "HP Victus 15L TG02-0021ns AMD Ryzen 7 5700G/16GB/1TB+512GB SSD/RTX 3060",
    precio: 650,
    enlace: "https://www.pccomponentes.com/hp-victus-15l-tg02-0021ns-amd-ryzen-7-5700g-16gb-1tb-512gb-ssd-rtx-3060",
    imagen: "pc6.JPG",
    tipo: "ordenador"
  },
  {
    identificación:6,
    nombre: "HP Pro Tower 400 G9 Intel Core i5-12500/16GB/512GB SSD",
    precio: 669,
    enlace: "https://www.pccomponentes.com/hp-pro-tower-400-g9-intel-core-i5-12500-16gb-512gb-ssd?refurbished",
    imagen: "pc7.JPG",
    tipo: "ordenador"
  },
  {
    identificación:7,
    nombre: "HP Z6 G4 Intel Xeon Silver 4112/16GB/512GB SSD/Quadro P2000",
    precio: 783,
    enlace: "https://www.pccomponentes.com/hp-pavilion-desktop-tp01-4006ns-intel-core-i5-13400-16gb-512gb-ssd",
    imagen: "pc8.JPG",
    tipo: "ordenador"
  },
  {
    identificación:8,
    nombre: "HP Pavilion Desktop TP01-4006ns Intel Core i5-13400/16GB/512GB SSD",
    precio: 749 ,
    enlace: "https://www.pccomponentes.com/hp-pavilion-desktop-tp01-4006ns-intel-core-i5-13400-16gb-512gb-ssd",
    imagen: "pc9.JPG",
    tipo: "ordenador"
  },
  {
    identificación:9,
    nombre: "HP 290 MT Sobremesa Intel Core i3-10110U/8GB/256GB SSD",
    precio: 500,
    enlace: "https://www.pccomponentes.com/hp-290-mt-sobremesa-intel-core-i3-10110u-8gb-256gb-ssd",
    imagen: "pc10.JPG",
    tipo: "ordenador"
  },
  {
    identificación:10,
    nombre: "Iggual Psipch603 Intel Core i5-10400/8GB/480GB SSD",
    precio: 390,
    enlace: "https://www.pccomponentes.com/iggual-psipch603-intel-core-i5-10400-8gb-480gb-ssd",
    imagen: "pc11.JPG",
    tipo: "ordenador"
  },
  {
    identificación:11,
    nombre: "Lenovo IdeaCentre 3 07ACH7 AMD Ryzen 5 5600H/8GB/512GB SSD",
    precio: 480,
    enlace: "https://www.pccomponentes.com/lenovo-ideacentre-3-07ach7-amd-ryzen-5-5600h-8gb-512gb-ssd",
    imagen: "pc12.JPG",
    tipo: "ordenador"
  },
  {
    identificación:12,
    nombre: "PcCom Work AMD Ryzen 7 5700G/16GB/500GB SSD",
    precio: 605,
    enlace: "https://www.pccomponentes.com/pccom-work-amd-ryzen-7-5700g-16gb-500gb-ssd ",
    imagen: "pc13.JPG",
    tipo: "ordenador"
  },
  {
    identificación:13,
    nombre: "IPHONE 15 PRO",
    precio: 1219,
    enlace: "https://www.apple.com/es/shop/buy-iphone/iphone-15-pro",
    imagen: "movil1.JPG",
    tipo: "movil"
  },
  {
    identificación:14,
    nombre: "IPHONE 14",
    precio: 859,
    enlace: "https://www.apple.com/es/shop/buy-iphone/iphone-14",
    imagen: "movil2.JPG",
    tipo: "movil"
  },
  {
    identificación:15,
    nombre: "IPHONE 13 PRO",
    precio: 732,
    enlace: "https://www.apple.com/es/shop/buy-iphone/iphone-13",
    imagen: "movil3.JPG",
    tipo: "movil"
  },
  {
    identificación:16,
    nombre: "IPHONE 12 PRO MAX",
    precio: 573,
    enlace: "https://www.backmarket.es/es-es/p/iphone-12-pro-max-256-gb-azul-pacifico-libre/3c52ddef-7498-4cc2-9abe-0a7bf225a58b#l=12",
    imagen: "movil4.JPG",
    tipo: "movil"
  },
  {
    identificación:17,
    nombre: "REALME 10",
    precio: 200,
    enlace: "https://www.elcorteingles.es/electronica/A48264763-realme-10-8-gb--256-gb-rush-black-movil-libre/?parentCategoryId=999.23716186013&color=Negro",
    imagen: "movil5.JPG",
    tipo: "movil"
  },
  {
    identificación:18,
    nombre: "HUAWEY NOVA 5T",
    precio: 459,
    enlace: "https://www.amazon.es/Huawei-Nova-128GB-Dual-SIM-Black/dp/B081R9T8P7/ref=sr_1_7?adgrpid=1305120739217769&dib=eyJ2IjoiMSJ9.F4RLyDJxuov2ftMlsImtYFyhHvnCzP-KoOlGB28HHmGSNRIOldkl7PLYLdVRRNbmQYK0mm7z_o9URv-jhtuMP9e5WCgfDXlTZnffQuvk89bOvz_9M9_mNvMYqVMJmMZ7qes01FciEEAOX6Q9CHu0BrqegxdTE_eociXOXF-cGcf4ah54ovPa1qPE1WXjASo53uTM9vgeW8Ak-QavmAqguV7YI2hRqbRdfUZFWEn2VVBSnWO7kHdvaY6Q3_B7HgUapo_mXAa6VAkcEueBeJy66XVejZrR4QWO9R8W6Q3Llh4.hVdVL6Pm1FVPz3RsqLd-Ume49_Jt71dgh4rGEmzFlQk&dib_tag=se&hvadid=81570135283581&hvbmt=be&hvdev=c&hvlocphy=164363&hvnetw=o&hvqmt=e&hvtargid=kwd-81570285685361%3Aloc-170&hydadcr=13840_1873108&keywords=huawei+nova+5t&qid=1705755404&sr=8-7&ufe=app_do%3Aamzn1.fos.5e544547-1f8e-4072-8c08-ed563e39fc7d",
    imagen: "movil6.JPG",
    tipo: "movil"
  },
  {
    identificación:19,
    nombre: "Smartphone Xiaomi Redmi Note 12 Pro",
    precio: 279,
    enlace: "https://www.amazon.es/dp/B0BW66P9XN?tag=track-ect-bing-es-58488-21&linkCode=osi&th=1&psc=1&ascsubtag=bnSEP1e5c5ojlrm5z6te",
    imagen: "movil7.JPG",
    tipo: "movil"
  },
  {
    identificación:20,
    nombre: "GOOGLE PIXEL 8 PRO",
    precio: 1159,
    enlace: "https://www.amazon.es/Google-Smartphone-teleobjetivo-autonom%C3%ADa-pantalla/dp/B0CGVVR11C/ref=sr_1_1_sspa?adgrpid=1296324645482753&dib=eyJ2IjoiMSJ9.ljJ6skjJuhZR_9N8jD2tSEB5tu_Gwhh1o-0o2hr_a4h4cXABqfHSKK4R_tXT0JbKSOwY1jqJsjaC_R8urrLdIQrqh4FQVGReHFLAzMHbSvKqluxo9BWGKDASVaVBu-BSMcgMONzBv5IqBD5n5aArzeoZPt8Dn9t0iVH79I2Fc7ogVCLGu_UJidMbPHIWoSh6tlYndIVYghLGA9aGR51srkdkrzHsmxI2AhBVDXJnnL-I-foBVRwuqtgHcizeXpYEbR4sotkqU7QApQgV83JYUkjmO0pgM36k_rTStSrlqso.67DWRPqRzRxvhmGAmemN9S5i5BJ7wnH4aKl-kYMutV0&dib_tag=se&hvadid=81020379445280&hvbmt=be&hvdev=c&hvlocphy=164363&hvnetw=o&hvqmt=e&hvtargid=kwd-81020530965849%3Aloc-170&hydadcr=3227_1852640&keywords=oneplus+11&qid=1705761136&sr=8-1-spons&ufe=app_do%3Aamzn1.fos.b8bc9a6f-1736-42c4-aea9-80869631c4db&sp_csd=d2lkZ2V0TmFtZT1zcF9hdGY&psc=1",
    imagen: "movil8.JPG",
    tipo: "movil"
  },
  {
    identificación:21,
    nombre: "Tempest K11 Ogre",
    precio: 37,
    enlace: "https://www.pccomponentes.com/tempest-k11-ogre-teclado-mecanico-gaming-rgb-negro",
    imagen: "teclado1.JPG",
    tipo: "periferico"
  },
  {
    identificación:22,
    nombre: "Trust Nado",
    precio: 29,
    enlace: "https://www.pccomponentes.com/trust-nado-teclado-inalambrico-bluetooth-blanco",
    imagen: "teclado2.JPG",
    tipo: "periferico"
  },
  {
    identificación:23,
    nombre: "Steelseries Rival 3 Ratón Óptico Gaming 8500DPI",
    precio: 33,
    enlace: "https://www.pccomponentes.com/steelseries-rival-3-raton-optico-gaming-8500dpi",
    imagen: "raton1.JPG",
    tipo: "periferico"
  },
  {
    identificación:24,
    nombre: "Trust GXT 609 Zoxa Altavoces para PC RGB 12W",
    precio: 1159,
    enlace: "https://www.pccomponentes.com/trust-gxt-609-zoxa-altavoces-para-pc-rgb-12w",
    imagen: "altavoz1.JPG",
    tipo: "periferico"
  },
  {
    identificación:25,
    nombre: "Aisens ASM2-RGB012",
    precio: 17,
    enlace: "https://www.pccomponentes.com/aisens-asm2-rgb012b-caja-externa-para-disco-ssd-m2-sata-nvme-usb-c",
    imagen: "disco1.JPG",
    tipo: "almacenamiento"
  },
  {
    identificación:26,
    nombre: "Dahua Technology C800A 2.5",
    precio: 69,
    enlace: "https://www.pccomponentes.com/dahua-technology-c800a-25-960gb-ssd-sata-3",
    imagen: "disco2.JPG",
    tipo: "almacenamiento"
  },
  {
    identificación:27,
    nombre: "Aisens ASUC-M2D012-GR Dock",
    precio: 34,
    enlace: "https://www.pccomponentes.com/aisens-asuc-m2d012-gr-dock-de-usb-c-a-m2-ngff-sata-nvme-gris",
    imagen: "disco3.JPG",
    tipo: "almacenamiento"
  },
  {
    identificación:28,
    nombre: "Samsung T7 Shield",
    precio: 129,
    enlace: "https://www.pccomponentes.com/samsung-t7-shield-disco-duro-ssd-1tb-usb-c-beige",
    imagen: "disco4.JPG",
    tipo: "almacenamiento"
  },
  

];

function extraerDatosProducto(contenedor) {
  // Obtener el nombre del producto
  var nombreProducto = contenedor.querySelector('.producto h4').textContent;

  // Obtener el precio del producto
  var precioTexto = contenedor.querySelector('.texto-encima B').textContent;
  var precio = parseFloat(precioTexto.replace('PRECIO:', '').replace('€', ''));

  // Obtener el enlace del producto
  var enlaceProducto = contenedor.querySelector('a').getAttribute('href');

  // Obtener el nombre de la imagen del producto
  var imagenProducto = contenedor.querySelector('img').getAttribute('src');

  // Crear un objeto con los datos extraídos
  var producto = {
    nombre: nombreProducto,
    precio: precio,
    enlace: enlaceProducto,
    imagen: imagenProducto
  };

  return producto;
}

function mostrarProductos(productos) {
  var resultadosHTML = ""; // Variable para almacenar el HTML de los productos
  
  // Iterar sobre cada producto y construir el HTML correspondiente
  productos.forEach(function(producto) {
      if (producto) {
          // Construir el HTML del producto
          resultadosHTML += `
      <div class="contenedor">
        <div><a href="${producto.enlace}" class="enlace-imagen"><img src="${producto.imagen}" alt="${producto.nombre}" width="200" height="150" class="imagen-producto"></a></div>
        <div class="producto"><h4>${producto.nombre}</h4></div>
        <div class="texto-encima"><h4><B class="letter">PRECIO: ${producto.precio}€</B></h4></div>
        <div class="texto-encima boton-agregar">
          <button onclick="añadir('${producto.nombre}', ${producto.precio}, ${producto.identificación})" id="boton${producto.identificación}">AGREGAR A CESTA</button>
        </div>
      </div>`;
      }
  });
  
  // Actualizar el contenido del contenedor de resultados con el HTML generado
  document.getElementById("resultados").innerHTML = resultadosHTML;
}

document.addEventListener("DOMContentLoaded", function() {
  // Asignar la función filtrar al botón de filtrar
  document.getElementById("btnFiltrar").addEventListener("click", filtrar);
});

let cesta = [];
let precioTotal = 0;
let cantidadEnCesta = 0;

// Función para agregar un producto a la cesta
function agregarACesta(identificacion, nombre, precio) {
    // Añadir el producto a la cesta
    cesta.push({ identificacion: identificacion, nombre: nombre, precio: precio });
    
    // Incrementar la cantidad de productos en la cesta
    cantidadEnCesta++;
    // Actualizar el elemento HTML que muestra la cantidad
    document.getElementById('cantidad').innerText = cantidadEnCesta;
    
    // Sumar el precio del producto al precio total
    precioTotal += precio;
    // Actualizar el elemento HTML que muestra el precio total
    document.getElementById('totalp').innerText = precioTotal + "€";
}

function filtrar() {
  // Obtener precio mínimo, máximo y tipo de producto seleccionado
  var precioMin = parseFloat(document.getElementById("precioMinimo").value);
  var precioMax = parseFloat(document.getElementById("precioMaximo").value);
  var tipoProducto = document.getElementById("tipoProducto").value;

  // Filtrar los productos según el rango de precios y tipo de producto
  var productosFiltrados = productos.filter(function(producto) {
    // Filtrar por precio
    var filtroPrecio = producto.precio >= precioMin && producto.precio <= precioMax;

    // Filtrar por tipo de producto
    var filtroTipo = tipoProducto === "todos" || producto.tipo === tipoProducto;

    return filtroPrecio && filtroTipo;
  });

  // Mostrar los productos filtrados en HTML
  mostrarProductos(productosFiltrados);
}

function limpiarResultados() {
  // Limpiar el contenido del contenedor de resultados
  document.getElementById("resultados").innerHTML = "";
}








let cantidad1=0
let cantidad2=0
let cantidad3=0
let cantidad4=0
let cantidad5=0
let cantidad6=0
let cantidad7=0
let cantidad8=0
let cantidad9=0
let cantidad10=0
let cantidad11=0
let cantidad12=0
let cantidad13=0
let cantidad14=0
let cantidad15=0
let cantidad16=0
let cantidad17=0
let cantidad18=0
let cantidad19=0
let cantidad20=0
let cantidad21=0
let cantidad22=0
let cantidad23=0
let cantidad24=0
let cantidad25=0
let cantidad26=0
let cantidad27=0
let cantidad28=0



// AÑADIR PRODUCTOS A LA CESTA 
const botonCesta = document.getElementById('botone');
let preciototal = 0;
function añadir(producto, precio, identificación) {//función 'añadir' que toma tres parámetros: producto, precio e identificación
    let cantidad = document.getElementById('cantidad');//  variable cantidad
    cantidad.innerText = parseInt(cantidad.innerText) + 1; // Actualiza la cantidad de productos que hay en la cesta, indicando que cada vez que se ñade un producto se suma 1
    preciototal += parseInt(precio);// Suma el precio del producto al precio total
    let preciot = document.getElementById('totalp');// variable preciot
    preciot.innerText = preciototal;// Actualiza el contenido del elemento preciot con el nuevo precio total
    localStorage.setItem('total', preciototal.toString());// Almacena el precio total
    if (identificación !== 0) {// si el valor de identificación no es 0 llama a la función
      total2(preciototal);
      total3(precio,producto);
      meterencesta(identificación);
      alert("Se ha añadido el producto a la cesta")
    } else {// Si la identificación es 0, no hace nada y retorna
      return;
    }
}

//Precio dentro de la cesta
function total2(precio) {
  let precioEnCesta = document.getElementById('botone2');
  precioEnCesta.innerText = preciototal;
}

// Cesta en el lateral
const botone3 = document.getElementById('botone3');
let preciototal1 = 0;

function total3(precio,producto,identificación) {
  let cantidadcesta = document.getElementById('cantidadcesta');//  variable cantidad
  let preciot1 = document.getElementById('totalp1');// variable preciot
  cantidadcesta.innerText = parseInt(cantidadcesta.innerText) +1; // Actualiza la cantidad de productos que hay en la cesta, indicando que cada vez que se ñade un producto se suma 1
  preciototal1 += parseInt(precio);// Suma el precio del producto al precio total
  localStorage.setItem('total', preciototal1.toString());// Almacena el precio total
  preciot1.innerText = preciototal1;// Actualiza el contenido del elemento preciot con el nuevo precio totat
  if (identificación !== 0) {// si el valor de identificación no es 0 llama a la función
    meterencesta(identificación);
  } else {// Si la identificación es 0, no hace nada y retorna
    return;
  }
}



//CREACION CESTA
document.addEventListener('DOMContentLoaded', function () {
  const cesta = document.getElementById('miCesta');//variable cesta
  const botonAbrir = document.getElementById('botone');//variable botonAbrir
  const botonAbrir1 = document.getElementById('botone1');//variable botonAbrir
  const botonAbrir2 = document.getElementById('botone3');//variable botonAbrir
  botonAbrir.addEventListener('click', function () {// Agrega un evento de clic al botón
    const cestaAbierta = cesta.style.left === '0px';// Verifica si la cesta está actualmente abierta
    if (cestaAbierta) { //Si la cesta está abierta, la cierra y ajusta el margen izquierdo del cuerpo del documento
      cesta.style.left = '-450px';
      document.body.style.marginLeft = '0';
    } else { // Si la cesta está cerrada, la abre y ajusta el margen izquierdo del cuerpo del documento 
      cesta.style.left = '0';
      document.body.style.marginLeft = '250px';
    }
  });
  botonAbrir1.addEventListener('click', function () {// Agrega un evento de clic al botón
    const cestaAbierta = cesta.style.left === '0px';// Verifica si la cesta está actualmente abierta
    if (cestaAbierta) { //Si la cesta está abierta, la cierra y ajusta el margen izquierdo del cuerpo del documento
      cesta.style.left = '-450px';
      document.body.style.marginLeft = '0';
    } else { // Si la cesta está cerrada, la abre y ajusta el margen izquierdo del cuerpo del documento 
      cesta.style.left = '0';
      document.body.style.marginLeft = '250px';
    }
  });
  botonAbrir2.addEventListener('click', function () {// Agrega un evento de clic al botón
    const cestaAbierta = cesta.style.left === '0px';// Verifica si la cesta está actualmente abierta
    if (cestaAbierta) { //Si la cesta está abierta, la cierra y ajusta el margen izquierdo del cuerpo del documento
      cesta.style.left = '-450px';
      document.body.style.marginLeft = '0';
    } else { // Si la cesta está cerrada, la abre y ajusta el margen izquierdo del cuerpo del documento 
      cesta.style.left = '0';
      document.body.style.marginLeft = '250px';
    }
  });
});



//APARICION PRODUCTO EN LA CESTA
function meterencesta(identificación) { // función meterencesta que toma un parámetro: identificación
  var cc = document.getElementById("contenidocesta");// variable cc(contenidocesta)

  // Verifica la identificación y agrega el producto correspondiente a la variable cc(contenidocesta)
  if (identificación === 1) {
    
    if (cantidad1 === 0) {
    cc.innerHTML += '<li><img src="../imagenes/pc1.JPG" alt="Lenovo torre PC LOQ3 i5 RTX-4060" width="200" height="150" class="original1"><p class="textocesta">-Lenovo torre PC LOQ3 i5 RTX-4060<br><b>Precio:600€</b></p>x<span id="cantidad1">1</span><br><button onclick="clickearOtroBoton(1)">+</button><button onclick="quitar(1, 600)">-</button><button onclick="Eliminar(1, 600)">eliminar</button><hr></li>'; 
  cantidad1 = 1;  
  }
  else {///incrementa la cantidad en 1 la cantidad
    cantidad1++;
    document.getElementById("cantidad1").innerHTML = cantidad1;
  }



} else if (identificación === 2) {

  if (cantidad2 === 0) {
  cc.innerHTML += '<li><img src="../imagenes/pc3.JPG" alt="HP Pavilion TP01-4004ns Intel Core i5-13400/16GB/1TB+512GB SSD" width="100" height="150" class="original1"><p class="textocesta">-HP Pavilion TP01-4004ns Intel Core i5-13400/16GB/1TB+512GB SSD<br><b>Precio: 400€</b></p>x<span id="cantidad2">1</span><br><button onclick="clickearOtroBoton(2)">+</button><button onclick="quitar(2, 400)">-</button><button onclick="Eliminar(2, 400)">eliminar</button><hr></li>';
cantidad2 = 1;
}
else {
  cantidad2++;
  document.getElementById("cantidad2").innerHTML = cantidad2;
}

  } else if (identificación === 3) {

    if (cantidad3 === 0) {
    cc.innerHTML += '<li><img src="../imagenes/pc4.JPG" alt="HP Slim Desktop S01-pF2027ns Intel Core i5-12400/8GB/256GB SSD" width="100" height="150" class="original1"><p class="textocesta">-HP Slim Desktop S01-pF2027ns Intel Core i5-12400/8GB/256GB SSD<br><b>Precio:459€</b></p>x<span id="cantidad3">1</span><br><button onclick="clickearOtroBoton(3)">+</button><button onclick="quitar(3, 459)">-</button><button onclick="Eliminar(3, 459)">eliminar</button><hr></li>';
    cantidad3 = 1;
  }
  else {
    cantidad3++;
    document.getElementById("cantidad3").innerHTML = cantidad3;
  }
  
} else if (identificación === 4) {

  if (cantidad4 === 0) {
  cc.innerHTML += '<li><img src="../imagenes/pc5.JPG" alt="HP EliteDesk 800 G5 SFF Intel Core i5-9500/8GB/256GB SSD" width="200" height="150" class="original"><p class="textocesta">-HP EliteDesk 800 G5 SFF Intel Core i5-9500/8GB/256GB SSD<br><b>Precio:400€</b></p>x<span id="cantidad4">1</span><br><button onclick="clickearOtroBoton(4)">+</button><button onclick="quitar(4, 400)">-</button><button onclick="Eliminar(4, 400)">eliminar</button><hr></li>';
  cantidad4 = 1;
}
else {
  cantidad4++;
  document.getElementById("cantidad4").innerHTML = cantidad4;
}

} else if (identificación === 5) {

  if (cantidad5 === 0) {
  cc.innerHTML += '<li><img src="../imagenes/pc6.JPG" alt="HP Victus 15L TG02-0021ns AMD Ryzen 7 5700G/16GB/1TB+512GB SSD/RTX 3060" width="200" height="150" class="original1"><p class="textocesta">-HP Victus 15L TG02-0021ns AMD Ryzen 7 5700G/16GB/1TB+512GB SSD/RTX 3060<br><b>Precio:650€</b></p>x<span id="cantidad5">1</span><br><button onclick="clickearOtroBoton(5)">+</button><button onclick="quitar(5, 650)">-</button><button onclick="Eliminar(5, 650)">eliminar</button><hr></li>';
  cantidad5 = 1;
}
else {
  cantidad5++;
  document.getElementById("cantidad5").innerHTML = cantidad5;
}

} else if (identificación === 6) {

  if (cantidad6 === 0) {
  cc.innerHTML += '<li><img src="../imagenes/pc7.JPG" alt="HP Pro Tower 400 G9 Intel Core i5-12500/16GB/512GB SSD" width="100" height="150" class="original1"><p class="textocesta">-HP Pro Tower 400 G9 Intel Core i5-12500/16GB/512GB SSD<br><b>Precio:669€</b></p>x<span id="cantidad6">1</span><br><button onclick="clickearOtroBoton(6)">+</button><button onclick="quitar(6, 669)">-</button><button onclick="Eliminar(6, 669)">eliminar</button><hr></li>';
  cantidad6 = 1;
}
else {
  cantidad6++;
  document.getElementById("cantidad6").innerHTML = cantidad6;
}

} else if (identificación === 7) {

  if (cantidad7 === 0) {
  cc.innerHTML += '<li><img src="../imagenes/pc8.JPG" alt="HP Z6 G4 Intel Xeon Silver 4112/16GB/512GB SSD/Quadro P2000" width="100" height="150" class="original1"><p class="textocesta">-HP Pro Tower 400 G9 Intel Core i5-12500/16GB/512GB SSD<br><b>Precio:783€</b></p>x<span id="cantidad7">1</span><br><button onclick="clickearOtroBoton(7)">+</button><button onclick="quitar(7, 783)">-</button><button onclick="Eliminar(7, 783)">eliminar</button><hr></li>';
  cantidad7 = 1;
}
else {
  cantidad7++;
  document.getElementById("cantidad7").innerHTML = cantidad7;
}

} else if (identificación === 8) {

  if (cantidad8 === 0) {
  cc.innerHTML += '<li><img src="../imagenes/pc9.JPG" alt="HP Pavilion Desktop TP01-4006ns Intel Core i5-13400/16GB/512GB SSD" width="200" height="150" class="original1"><p class="textocesta">-HP Pavilion Desktop TP01-4006ns Intel Core i5-13400/16GB/512GB SSD<br><b>Precio:749€</b></p>x<span id="cantidad8">1</span><br><button onclick="clickearOtroBoton(8)">+</button><button onclick="quitar(8, 749)">-</button><button onclick="Eliminar(8, 749)">eliminar</button><hr></li>';
  cantidad8 = 1;
}
else {
  cantidad8++;
  document.getElementById("cantidad8").innerHTML = cantidad8;
}

} else if (identificación === 9) {

  if (cantidad9 === 0) {
  cc.innerHTML += '<li><img src="../imagenes/pc10.JPG" alt="HP 290 MT Sobremesa Intel Core i3-10110U/8GB/256GB SSD" width="200" height="150" class="original1"><p class="textocesta">-HP 290 MT Sobremesa Intel Core i3-10110U/8GB/256GB SSD<br><b>Precio:500€</b></p>x<span id="cantidad9">1</span><br><button onclick="clickearOtroBoton(9)">+</button><button onclick="quitar(9, 500)">-</button><button onclick="Eliminar(9, 500)">eliminar</button><hr></li>';
  cantidad9 = 1;
}
else {
  cantidad9++;
  document.getElementById("cantidad9").innerHTML = cantidad9;
}

} else if (identificación === 10) {

  if (cantidad10 === 0) {
  cc.innerHTML += '<li><img src="../imagenes/pc11.JPG" alt="Iggual Psipch603 Intel Core i5-10400/8GB/480GB SSD" width="100" height="150" class="original1"><p class="textocesta">-Iggual Psipch603 Intel Core i5-10400/8GB/480GB SSD<br><b>Precio:390€</b></p>x<span id="cantidad10">1</span><br><button onclick="clickearOtroBoton(10)">+</button><button onclick="quitar(10, 390)">-</button><button onclick="Eliminar(10, 390)">eliminar</button><hr></li>';
  cantidad10 = 1;
}
else {
  cantidad10++;
  document.getElementById("cantidad10").innerHTML = cantidad10;
}

} else if (identificación === 11) {

  if (cantidad11 === 0) {
  cc.innerHTML += '<li><img src="../imagenes/pc12.JPG" alt="Lenovo IdeaCentre 3 07ACH7 AMD Ryzen 5 5600H/8GB/512GB SSD" width="100" height="150" class="original1"><p  class="textocesta">-Lenovo IdeaCentre 3 07ACH7 AMD Ryzen 5 5600H/8GB/512GB SSD<br><b>Precio:480€</b></p>x<span id="cantidad11">1</span><br><button onclick="clickearOtroBoton(11)">+</button><button onclick="quitar(11, 480)">-</button><button onclick="Eliminar(11, 480)">eliminar</button><hr></li>';
  cantidad11 = 1;
}
else {
  cantidad11++;
  document.getElementById("cantidad11").innerHTML = cantidad11;
}

} else if (identificación === 12) {

  if (cantidad12 === 0) {
  cc.innerHTML += '<li><img src="../imagenes/pc13.JPG" alt="PcCom Work AMD Ryzen 7 5700G/16GB/500GB SSD" width="200" height="150" class="original1"><p class="textocesta">-PcCom Work AMD Ryzen 7 5700G/16GB/500GB SSD<br><b>Precio:480€</b></p>x<span id="cantidad12">1</span><br><button onclick="clickearOtroBoton(12)">+</button><button onclick="quitar(12, 605)">-</button><button onclick="Eliminar(12, 605)">eliminar</button><hr></li>';
  cantidad12 = 1;
}
else {
  cantidad12++;
  document.getElementById("cantidad12").innerHTML = cantidad12;
}

} else if (identificación === 13) {

  if (cantidad13 === 0) {
  cc.innerHTML += '<li><img src="../imagenes/movil1.JPG" alt="Iphone 15 pro" width="200" height="150" class="original1"><p class="textocesta">-IPHONE 15 PRO<br><b>Precio:1219€</b></p>x<span id="cantidad13">1</span><br><button onclick="clickearOtroBoton(13)">+</button><button onclick="quitar(13, 1219)">-</button><button onclick="Eliminar(13, 1219)">eliminar</button><hr></li>';
  cantidad13 = 1;
}
else {
  cantidad13++;
  document.getElementById("cantidad13").innerHTML = cantidad13;
}

} else if (identificación === 14) {

  if (cantidad14 === 0) {
  cc.innerHTML += '<li><img src="../imagenes/movil2.JPG" alt="Iphone 14" width="200" height="150" class="original1"><p class="textocesta">-IPHONE 14<br><b>Precio:859€</b></p>x<span id="cantidad14">1</span><br><button onclick="clickearOtroBoton(14)">+</button><button onclick="quitar(14, 859)">-</button><button onclick="Eliminar(14, 859)">eliminar</button><hr></li>';
  cantidad14 = 1;
}
else {
  cantidad14++;
  document.getElementById("cantidad14").innerHTML = cantidad14;
}

} else if (identificación === 15) {

  if (cantidad15 === 0) {
  cc.innerHTML += '<li><img src="../imagenes/movil3.JPG" alt="Iphone 13 pro" width="200" height="150" id="movil31" class="original1"><p class="textocesta">-IPHONE 13 PRO<br><b>Precio:732€</b></p>x<span id="cantidad15">1</span><br><button onclick="clickearOtroBoton(15)">+</button><button onclick="quitar(15, 732)">-</button><button onclick="Eliminar(15, 732)">eliminar</button><hr></li>';
  cantidad15 = 1;
}
else {
  cantidad15++;
  document.getElementById("cantidad15").innerHTML = cantidad15;
}

} else if (identificación === 16) {

  if (cantidad16 === 0) {
  cc.innerHTML += '<li><img src="../imagenes/movil4.JPG" alt="IPHONE 12 PRO MAX" width="200" height="150" class="original1"><p class="textocesta">-IPHONE 12 PRO MAX<br><b>Precio:573€</b></p>x<span id="cantidad16">1</span><br><button onclick="clickearOtroBoton(16)">+</button><button onclick="quitar(16, 573)">-</button><button onclick="Eliminar(16, 573)">eliminar</button><hr></li>';
  cantidad16 = 1;
}
else {
  cantidad16++;
  document.getElementById("cantidad16").innerHTML = cantidad16;
}

} else if (identificación === 17) {

  if (cantidad17 === 0) {
  cc.innerHTML += '<li><img src="../imagenes/movil5.JPG" alt="REALME 10" width="200" height="150" class="original1"><p class="textocesta">-REALME 10<br><b>Precio:200€</b></p>x<span id="cantidad17">1</span><br><button onclick="clickearOtroBoton(17)">+</button><button onclick="quitar(17, 200)">-</button><button onclick="Eliminar(17, 200)">eliminar</button><hr></li>';
  cantidad17 = 1;
}
else {
  cantidad17++;
  document.getElementById("cantidad17").innerHTML = cantidad17;
}

} else if (identificación === 18) {

  if (cantidad18 === 0) {
  cc.innerHTML += '<li><img src="../imagenes/movil6.JPG" alt="Huawei Nova 5T" width="100" height="150" class="original1"><p class="textocesta">-HUAWEY NOVA 5T<br><b>Precio:459€</b></p>x<span id="cantidad18">1</span><br><button onclick="clickearOtroBoton(18)">+</button><button onclick="quitar(18, 459)">-</button><button onclick="Eliminar(18, 459)">eliminar</button><hr></li>';
  cantidad18 = 1;
}
else {
  cantidad18++;
  document.getElementById("cantidad18").innerHTML = cantidad18;
}

} else if (identificación === 19) {

  if (cantidad19 === 0) {
  cc.innerHTML += '<li><img ="../imagenes/movil7.JPG" alt="Smartphone Xiaomi Redmi Note 12 Pro" width="200" height="150" class="original1"><p class="textocesta">-Smartphone Xiaomi Redmi Note 12 Pro<br><b>Precio:279€</b></p>x<span id="cantidad19">1</span><br><button onclick="clickearOtroBoton(19)">+</button><button onclick="quitar(19, 279)">-</button><button onclick="Eliminar(19, 279)">eliminar</button><hr></li>';
  cantidad19 = 1;
}
else {
  cantidad19++;
  document.getElementById("cantidad19").innerHTML = cantidad19;
}

} else if (identificación === 20) {

  if (cantidad20 === 0) {
  cc.innerHTML += '<li><img src="../imagenes/movil8.JPG" alt="GOOGLE PIXEL 8 PRO" width="200" height="150" class="original1"><p class="textocesta">-GOOGLE PIXEL 8 PRO<br><b>Precio:1159€</b></p>x<span id="cantidad20">1</span><br><button onclick="clickearOtroBoton(20)">+</button><button onclick="quitar(20, 1159)">-</button><button onclick="Eliminar(20, 1159)">eliminar</button><hr></li>';
  cantidad20 = 1;
}
else {
  cantidad20++;
  document.getElementById("cantidad20").innerHTML = cantidad20;
}
}else if (identificación === 21) {

  if (cantidad21 === 0) {
  cc.innerHTML += '<li><img src="../imagenes/teclado1.JPG" alt="teclado cable" width="200" height="150" class="original"><p class="textocesta">-Tempest K11 Ogre<br><b>Precio:37€</b></p>x<span id="cantidad21">1</span><br><button onclick="clickearOtroBoton(21)">+</button><button onclick="quitar(21, 37)">-</button><button onclick="Eliminar(21, 37)">eliminar</button><hr></li>';
  cantidad21 = 1;
}
else {
  cantidad21++;
  document.getElementById("cantidad21").innerHTML = cantidad21;
}
}else if (identificación === 22) {

  if (cantidad22 === 0) {
  cc.innerHTML += '<li><img src="../imagenes/teclado2.JPG" alt="teclado inalambrico" width="200" height="150" class="original"><p class="textocesta">-Trust Nado<br><b>Precio:29€</b></p>x<span id="cantidad22">1</span><br><button onclick="clickearOtroBoton(22)">+</button><button onclick="quitar(22, 29)">-</button><button onclick="Eliminar(22, 29)">eliminar</button><hr></li>';
  cantidad22 = 1;
}
else {
  cantidad22++;
  document.getElementById("cantidad22").innerHTML = cantidad22;
}
}else if (identificación === 23) {

  if (cantidad23 === 0) {
  cc.innerHTML += '<li><img src="../imagenes/raton1.JPG" alt="raton cable" width="200" height="150" class="original1"><p class="textocesta">-Steelseries Rival 3 Ratón Óptico Gaming 8500DPI<br><b>Precio:33€</b></p>x<span id="cantidad23">1</span><br><button onclick="clickearOtroBoton(23)">+</button><button onclick="quitar(23, 33)">-</button><button onclick="Eliminar(23, 33)">eliminar</button><hr></li>';
  cantidad23 = 1;
}
else {
  cantidad23++;
  document.getElementById("cantidad23").innerHTML = cantidad23;
}
}else if (identificación === 24) {

  if (cantidad24 === 0) {
  cc.innerHTML += '<li><img src="../imagenes/altavoz1.JPG" alt="altavoz" width="200" class="original1"><p class="textocesta">-Trust GXT 609 Zoxa Altavoces para PC RGB 12W<br><b>Precio:31€</b></p>x<span id="cantidad24">1</span><br><button onclick="clickearOtroBoton(24)">+</button><button onclick="quitar(24, 31)">-</button><button onclick="Eliminar(24, 31)">eliminar</button><hr></li>';
  cantidad24 = 1;
}
else {
  cantidad24++;
  document.getElementById("cantidad24").innerHTML = cantidad24;
}
}else if (identificación === 25) {

  if (cantidad25 === 0) {
  cc.innerHTML += '<li><img src="../imagenes/disco1.JPG" alt="disco1" width="200" height="150" class="original1"><p class="textocesta ">-Aisens ASM2-RGB012<br><b>Precio:17€</b></p>x<span id="cantidad25">1</span><br><button onclick="clickearOtroBoton(25)">+</button><button onclick="quitar(25, 17)">-</button><button onclick="Eliminar(25, 17)">eliminar</button><hr></li>';
  cantidad25 = 1;
}
else {
  cantidad25++;
  document.getElementById("cantidad25").innerHTML = cantidad25;
}
}else if (identificación === 26) {

  if (cantidad26 === 0) {
  cc.innerHTML += '<li><img src="../imagenes/disco2.JPG" alt="disco2" width="200" height="150" class="original"><p class="textocesta">-Dahua Technology C800A 2.5<br><b>Precio:69€</b></p>x<span id="cantidad26">1</span><br><button onclick="clickearOtroBoton(26)">+</button><button onclick="quitar(26, 69)">-</button><button onclick="Eliminar(26, 69)">eliminar</button><hr></li>';
  cantidad26 = 1;
}
else {
  cantidad26++;
  document.getElementById("cantidad26").innerHTML = cantidad26;
}
}else if (identificación === 27) {

  if (cantidad27 === 0) {
  cc.innerHTML += '<li><img src="../imagenes/disco3.JPG" alt="disco3" width="200" height="150" class="original1"><p class="textocesta">-Aisens ASUC-M2D012-GR Dock<br><b>Precio:34€</b></p>x<span id="cantidad27">1</span><br><button onclick="clickearOtroBoton(27)">+</button><button onclick="quitar(27, 34)">-</button><button onclick="Eliminar(27, 34)">eliminar</button><hr></li>';
  cantidad27 = 1;
}
else {
  cantidad27++;
  document.getElementById("cantidad27").innerHTML = cantidad27;
}
}else if (identificación === 28) {

  if (cantidad28 === 0) {
  cc.innerHTML += '<li><img src="../imagenes/disco4.JPG" alt="Samsung T7 Shield" width="200" height="150" class="original"><p class="textocesta">-Samsung T7 Shield<br><b>Precio:129€</b></p>x<span id="cantidad28">1</span><br><button onclick="clickearOtroBoton(28)">+</button><button onclick="quitar(28, 129)">-</button><button onclick="Eliminar(28, 129)">eliminar</button><hr></li>';
  cantidad28 = 1;
}
else {
  cantidad28++;
  document.getElementById("cantidad28").innerHTML = cantidad28;
}
}
}

//FUNCION DEL BOTON "+" QUE ESATEN LA CESTA
function clickearOtroBoton(boton) {
  // Obtener el elemento del segundo botón
  let boton1 = document.getElementById("boton1");
  let boton2 = document.getElementById("boton2");
  let boton3 = document.getElementById("boton3");
  let boton4 = document.getElementById("boton4");
  let boton5 = document.getElementById("boton5");
  let boton6 = document.getElementById("boton6");
  let boton7 = document.getElementById("boton7");
  let boton8 = document.getElementById("boton8");
  let boton9 = document.getElementById("boton9");
  let boton10 = document.getElementById("boton10");
  let boton11 = document.getElementById("boton11");
  let boton12 = document.getElementById("boton12");
  let boton13 = document.getElementById("boton13");
  let boton14 = document.getElementById("boton14");
  let boton15 = document.getElementById("boton15");
  let boton16 = document.getElementById("boton16");
  let boton17 = document.getElementById("boton17");
  let boton18 = document.getElementById("boton18");
  let boton19 = document.getElementById("boton19");
  let boton20 = document.getElementById("boton20");
  let boton21 = document.getElementById("boton21");
  let boton22 = document.getElementById("boton22");
  let boton23 = document.getElementById("boton23");
  let boton24 = document.getElementById("boton24");
  let boton25 = document.getElementById("boton25");
  let boton26 = document.getElementById("boton26");
  let boton27 = document.getElementById("boton27");
  let boton28 = document.getElementById("boton28");



  // Simular un clic en el segundo botón
  if (boton === 1){
  añadir('', 600, 1)

  }else if (boton === 2){
  añadir('', 400, 2);

  }else if (boton === 3){
  añadir('', 459, 3);

  }else if (boton === 4){
  añadir('', 400, 4);

  }else if (boton === 5){
  añadir('', 650, 5);

  }else if (boton === 6){
  añadir('', 669, 6);

  }else if (boton === 7){
  añadir('', 783, 7);

  }else if (boton === 8){
  añadir('', 749, 8);

  }else if (boton === 9){
  añadir('', 500, 9);

  }else if (boton === 10){
  añadir('', 390, 10);

  }else if (boton === 11){
  añadir('', 480, 11);

  }else if (boton === 12){
  añadir('', 605, 12);

  }else if (boton === 13){
  añadir('', 1219, 13);

  }else if (boton === 14){
  añadir('', 859, 14);

  }else if (boton === 15){
  añadir('', 732, 15);

  }else if (boton === 16){
  añadir('', 573, 16);

  }else if (boton === 17){
  añadir('', 200, 17);

  }else if (boton === 18){
  añadir('', 459, 18);

  }else if (boton === 19){
  añadir('', 279, 19);

  }else if (boton === 20){
  añadir('', 1159, 20);

  }else if (boton === 21){
    añadir('', 37, 21);

  }else if (boton === 22){
  añadir('', 29, 22);

  }else if (boton === 23){
  añadir('', 33, 23);

  }else if (boton === 24){
  añadir('', 31, 24);

  }else if (boton === 25){
    añadir('', 17, 25);

  }else if (boton === 26){
  añadir('', 69, 26);

  }else if (boton === 27){
  añadir('', 34, 27);

  }else if (boton === 28){
  añadir('', 129, 28);
  }
  
}

//FUNCIÓN DEL "-" QUE ESTA DENTRO DE LA CESTA
function quitar(identificación, precio) {
  let preciot = document.getElementById('totalp')
  let preciot1 = document.getElementById('totalp1')
  let cantidadcesta = document.getElementById('cantidadcesta');//  variable cantidad
    var cc = document.getElementById("contenidocesta");
    cantidad.innerHTML = parseInt(cantidad.innerHTML) - 1;//Reduce la cantidad total de productos
    cantidadcesta.innerHTML = parseInt(cantidadcesta.innerHTML) - 2;//Reduce la cantidad total de productos
    preciototal = preciototal - precio //Resta el precio del producto
    preciototal1 = preciototal - precio //Resta el precio del producto
    preciot.innerHTML = preciototal //Actualiza el precio total mostrado en la página.
    preciot1.innerHTML = preciototal //Actualiza el precio total mostrado en la página.
    if (identificación === 1) {
      //Si la identificación del producto es 1 y la cantidad de ese producto es 1: elimina completamente el elemento correspondiente del carrito de compras y establece la cantidad de ese producto a 0.
      if (cantidad1 === 1) {
      cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/pc1.JPG" alt="Lenovo torre PC LOQ3 i5 RTX-4060" width="200" height="150" class="original1"><p class="textocesta">-Lenovo torre PC LOQ3 i5 RTX-4060<br><b>Precio:600€</b></p>x<span id="cantidad1">1</span><br><button onclick="clickearOtroBoton(1)">+</button><button onclick="quitar(1, 600)">-</button><button onclick="Eliminar(1, 600)">eliminar</button><hr></li>', '');
    cantidad1 = 0;
    }
    else { //Si la cantidad de ese producto es mayor que 1: reduce la cantidad de ese producto en 1 y actualiza la cantidad mostrada en la página para ese producto.
      cantidad1 = cantidad1 - 1;
      document.getElementById("cantidad1").innerHTML = cantidad1;
     }
    }else   if (identificación === 2) {
      
      if (cantidad2 === 1) {
      cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/pc3.JPG" alt="HP Pavilion TP01-4004ns Intel Core i5-13400/16GB/1TB+512GB SSD" width="100" height="150" class="original1"><p class="textocesta">-HP Pavilion TP01-4004ns Intel Core i5-13400/16GB/1TB+512GB SSD<br><b>Precio: 400€</b></p>x<span id="cantidad2">1</span><br><button onclick="clickearOtroBoton(2)">+</button><button onclick="quitar(2, 400)">-</button><button onclick="Eliminar(2, 400)">eliminar</button><hr></li>', '');
    cantidad2 = 0;
    }
    else {
      cantidad2 = cantidad2 - 1;
      document.getElementById("cantidad2").innerHTML = cantidad2;
     }


    }else   if (identificación === 3) {
      
      if (cantidad3 === 1) {
      cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/pc4.JPG" alt="HP Slim Desktop S01-pF2027ns Intel Core i5-12400/8GB/256GB SSD" width="100" height="150" class="original1"><p class="textocesta">-HP Slim Desktop S01-pF2027ns Intel Core i5-12400/8GB/256GB SSD<br><b>Precio:459€</b></p>x<span id="cantidad3">1</span><br><button onclick="clickearOtroBoton(3)">+</button><button onclick="quitar(3, 459)">-</button><button onclick="Eliminar(3, 459)">eliminar</button><hr></li>', '');
    cantidad3 = 0;
    }
    else {
      cantidad3 = cantidad3 - 1;
      document.getElementById("cantidad3").innerHTML = cantidad3;
     }


    }else if (identificación === 4) {
      
  if  (cantidad4 === 1) {
      cc.innerHTML = cc.innerHTML.replace( '<li><img src="../imagenes/pc5.JPG" alt="HP EliteDesk 800 G5 SFF Intel Core i5-9500/8GB/256GB SSD" width="200" height="150" class="original"><p class="textocesta">-HP EliteDesk 800 G5 SFF Intel Core i5-9500/8GB/256GB SSD<br><b>Precio:400€</b></p>x<span id="cantidad4">1</span><br><button onclick="clickearOtroBoton(4)">+</button><button onclick="quitar(4, 400)">-</button><button onclick="Eliminar(4, 400)">eliminar</button><hr></li>', '');
    cantidad4 = 0;
    }
    else {
      cantidad4 = cantidad4 - 1;
      document.getElementById("cantidad4").innerHTML = cantidad4;
     }
    
    }else if (identificación === 5) {
      
      if  (cantidad5 === 1) {
          cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/pc6.JPG" alt="HP Victus 15L TG02-0021ns AMD Ryzen 7 5700G/16GB/1TB+512GB SSD/RTX 3060" width="200" height="150" class="original1"><p class="textocesta">-HP Victus 15L TG02-0021ns AMD Ryzen 7 5700G/16GB/1TB+512GB SSD/RTX 3060<br><b>Precio:650€</b></p>x<span id="cantidad5">1</span><br><button onclick="clickearOtroBoton(5)">+</button><button onclick="quitar(5, 650)">-</button><button onclick="Eliminar(5, 650)">eliminar</button><hr></li>', '');
        cantidad5 = 0;
        }
        else {
          cantidad5 = cantidad5 - 1;
          document.getElementById("cantidad5").innerHTML = cantidad5;
         }
  }else if (identificación === 6) {
      
    if  (cantidad6 === 1) {
        cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/pc7.JPG" alt="HP Pro Tower 400 G9 Intel Core i5-12500/16GB/512GB SSD" width="100" height="150" class="original1"><p class="textocesta">-HP Pro Tower 400 G9 Intel Core i5-12500/16GB/512GB SSD<br><b>Precio:669€</b></p>x<span id="cantidad6">1</span><br><button onclick="clickearOtroBoton(6)">+</button><button onclick="quitar(6, 669)">-</button><button onclick="Eliminar(6, 669)">eliminar</button><hr></li>', '');
      cantidad6 = 0;
      }
      else {
        cantidad6 = cantidad6 - 1;
        document.getElementById("cantidad6").innerHTML = cantidad6;
       }
}else if (identificación === 7) {
      
  if  (cantidad7 === 1) {
      cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/pc8.JPG" alt="HP Z6 G4 Intel Xeon Silver 4112/16GB/512GB SSD/Quadro P2000" width="100" height="150" class="original1"><p class="textocesta">-HP Pro Tower 400 G9 Intel Core i5-12500/16GB/512GB SSD<br><b>Precio:783€</b></p>x<span id="cantidad7">1</span><br><button onclick="clickearOtroBoton(7)">+</button><button onclick="quitar(7, 783)">-</button><button onclick="Eliminar(7, 783)">eliminar</button><hr></li>', '');
    cantidad7 = 0;
    }
    else {
      cantidad7 = cantidad7 - 1;
      document.getElementById("cantidad7").innerHTML = cantidad7;
     }
}else if (identificación === 8) {
      
  if  (cantidad8 === 1) {
      cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/pc9.JPG" alt="HP Pavilion Desktop TP01-4006ns Intel Core i5-13400/16GB/512GB SSD" width="200" height="150" class="original1"><p class="textocesta">-HP Pavilion Desktop TP01-4006ns Intel Core i5-13400/16GB/512GB SSD<br><b>Precio:749€</b></p>x<span id="cantidad8">1</span><br><button onclick="clickearOtroBoton(8)">+</button><button onclick="quitar(8, 749)">-</button><button onclick="Eliminar(8, 749)">eliminar</button><hr></li>', '');
    cantidad8 = 0;
    }
    else {
      cantidad8 = cantidad8 - 1;
      document.getElementById("cantidad8").innerHTML = cantidad8;
     }
}else if (identificación === 9) {
      
  if  (cantidad9 === 1) {
      cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/pc10.JPG" alt="HP 290 MT Sobremesa Intel Core i3-10110U/8GB/256GB SSD" width="200" height="150" class="original1"><p class="textocesta">-HP 290 MT Sobremesa Intel Core i3-10110U/8GB/256GB SSD<br><b>Precio:500€</b></p>x<span id="cantidad9">1</span><br><button onclick="clickearOtroBoton(9)">+</button><button onclick="quitar(9, 500)">-</button><button onclick="Eliminar(9, 500)">eliminar</button><hr></li>', '');
    cantidad9 = 0;
    }
    else {
      cantidad9 = cantidad9 - 1;
      document.getElementById("cantidad9").innerHTML = cantidad9;
     }
}else if (identificación === 10) {
      
  if  (cantidad10 === 1) {
      cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/pc11.JPG" alt="Iggual Psipch603 Intel Core i5-10400/8GB/480GB SSD" width="100" height="150" class="original1"><p class="textocesta">-Iggual Psipch603 Intel Core i5-10400/8GB/480GB SSD<br><b>Precio:390€</b></p>x<span id="cantidad10">1</span><br><button onclick="clickearOtroBoton(10)">+</button><button onclick="quitar(10, 390)">-</button><button onclick="Eliminar(10, 390)">eliminar</button><hr></li>', '');
    cantidad10 = 0;
    }
    else {
      cantidad10 = cantidad10 - 1;
      document.getElementById("cantidad10").innerHTML = cantidad10;
     }
}else if (identificación === 11) {
      
  if  (cantidad11 === 1) {
      cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/pc12.JPG" alt="Lenovo IdeaCentre 3 07ACH7 AMD Ryzen 5 5600H/8GB/512GB SSD" width="100" height="150" class="original1"><p class="textocesta">-Lenovo IdeaCentre 3 07ACH7 AMD Ryzen 5 5600H/8GB/512GB SSD<br><b>Precio:480€</b></p>x<span id="cantidad11">1</span><br><button onclick="clickearOtroBoton(11)">+</button><button onclick="quitar(11, 480)">-</button><button onclick="Eliminar(11, 480)">eliminar</button><hr></li>', '');
    cantidad11 = 0;
    }
    else {
      cantidad11 = cantidad11 - 1;
      document.getElementById("cantidad11").innerHTML = cantidad11;
     }
}else if (identificación === 12) {
      
  if  (cantidad12 === 1) {
      cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/pc13.JPG" alt="PcCom Work AMD Ryzen 7 5700G/16GB/500GB SSD" width="200" height="150" class="original1"><p class="textocesta">-PcCom Work AMD Ryzen 7 5700G/16GB/500GB SSD<br><b>Precio:480€</b></p>x<span id="cantidad12">1</span><br><button onclick="clickearOtroBoton(12)">+</button><button onclick="quitar(12, 605)">-</button><button onclick="Eliminar(12, 605)">eliminar</button><hr></li>', '');
    cantidad12 = 0;
    }
    else {
      cantidad12 = cantidad12 - 1;
      document.getElementById("cantidad12").innerHTML = cantidad12;
     }
}else if (identificación === 13) {
      
  if  (cantidad13 === 1) {
      cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/movil1.JPG" alt="Iphone 15 pro" width="200" height="150" class="original1"><p class="textocesta">-IPHONE 15 PRO<br><b>Precio:1219€</b></p>x<span id="cantidad13">1</span><br><button onclick="clickearOtroBoton(13)">+</button><button onclick="quitar(13, 1219)">-</button><button onclick="Eliminar(13, 1219)">eliminar</button><hr></li>', '');
    cantidad13 = 0;
    }
    else {
      cantidad13 = cantidad13 - 1;
      document.getElementById("cantidad13").innerHTML = cantidad13;
     }
}else if (identificación === 14) {
      
  if  (cantidad14 === 1) {
      cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/movil2.JPG" alt="Iphone 14" width="200" height="150" class="original1"><p class="textocesta">-IPHONE 14<br><b>Precio:859€</b></p>x<span id="cantidad14">1</span><br><button onclick="clickearOtroBoton(14)">+</button><button onclick="quitar(14, 859)">-</button><button onclick="Eliminar(14, 859)">eliminar</button><hr></li>', '');
    cantidad14 = 0;
    }
    else {
      cantidad14 = cantidad14 - 1;
      document.getElementById("cantidad14").innerHTML = cantidad14;
     }
}else if (identificación === 15) {
      
  if  (cantidad15 === 1) {
      cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/movil3.JPG" alt="Iphone 13 pro" width="200" height="150" id="movil31" class="original1"><p class="textocesta">-IPHONE 13 PRO<br><b>Precio:732€</b></p>x<span id="cantidad15">1</span><br><button onclick="clickearOtroBoton(15)">+</button><button onclick="quitar(15, 732)">-</button><button onclick="Eliminar(15, 732)">eliminar</button><hr></li>', '');
    cantidad15 = 0;
    }
    else {
      cantidad15 = cantidad15 - 1;
      document.getElementById("cantidad15").innerHTML = cantidad15;
     }
}else if (identificación === 16) {
      
  if  (cantidad16 === 1) {
      cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/movil4.JPG" alt="IPHONE 12 PRO MAX" width="200" height="150" class="original1"><p class="textocesta">-IPHONE 12 PRO MAX<br><b>Precio:573€</b></p>x<span id="cantidad16">1</span><br><button onclick="clickearOtroBoton(16)">+</button><button onclick="quitar(16, 573)">-</button><button onclick="Eliminar(16, 573)">eliminar</button><hr></li>', '');
    cantidad16 = 0;
    }
    else {
      cantidad16 = cantidad16 - 1;
      document.getElementById("cantidad16").innerHTML = cantidad16;
     }
}else if (identificación === 17) {
      
  if  (cantidad17 === 1) {
      cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/movil5.JPG" alt="REALME 10" width="200" height="150" class="original1"><p class="textocesta">-REALME 10<br><b>Precio:200€</b></p>x<span id="cantidad17">1</span><br><button onclick="clickearOtroBoton(17)">+</button><button onclick="quitar(17, 200)">-</button><button onclick="Eliminar(17, 200)">eliminar</button><hr></li>', '');
    cantidad17 = 0;
    }
    else {
      cantidad17 = cantidad17 - 1;
      document.getElementById("cantidad17").innerHTML = cantidad17;
     }
}else if (identificación === 18) {
      
  if  (cantidad18 === 1) {
      cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/movil6.JPG" alt="Huawei Nova 5T" width="100" height="150" class="original1"><p class="textocesta">-HUAWEY NOVA 5T<br><b>Precio:459€</b></p>x<span id="cantidad18">1</span><br><button onclick="clickearOtroBoton(18)">+</button><button onclick="quitar(18, 459)">-</button><button onclick="Eliminar(18, 459)">eliminar</button><hr></li>', '');
    cantidad18 = 0;
    }
    else {
      cantidad18 = cantidad18 - 1;
      document.getElementById("cantidad18").innerHTML = cantidad18;
     }
}else if (identificación === 19) {
      
  if  (cantidad19 === 1) {
      cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/movil7.JPG" alt="Smartphone Xiaomi Redmi Note 12 Pro" width="200" height="150" class="original1"><p class="textocesta">-Smartphone Xiaomi Redmi Note 12 Pro<br><b>Precio:279€</b></p>x<span id="cantidad19">1</span><br><button onclick="clickearOtroBoton(19)">+</button><button onclick="quitar(19, 279)">-</button><button onclick="Eliminar(19, 279)">eliminar</button><hr></li>', '');
    cantidad19 = 0;
    }
    else {
      cantidad19 = cantidad19 - 1;
      document.getElementById("cantidad19").innerHTML = cantidad19;
     }
}else if (identificación === 20) {
      
  if  (cantidad20 === 1) {
      cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/movil8.JPG" alt="GOOGLE PIXEL 8 PRO" width="200" height="150" class="original1"><p class="textocesta">-GOOGLE PIXEL 8 PRO<br><b>Precio:1159€</b></p>x<span id="cantidad20">1</span><br><button onclick="clickearOtroBoton(20)">+</button><button onclick="quitar(20, 1159)">-</button><button onclick="Eliminar(20, 1159)">eliminar</button><hr></li>', '');
    cantidad20 = 0;
    }
    else {
      cantidad20 = cantidad20 - 1;
      document.getElementById("cantidad20").innerHTML = cantidad20;
     }
}else if (identificación === 21) {
      
  if  (cantidad21 === 1) {
      cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/teclado1.JPG" alt="teclado cable" width="200" height="150" class="original"><p class="textocesta">-Tempest K11 Ogre<br><b>Precio:37€</b></p>x<span id="cantidad21">1</span><br><button onclick="clickearOtroBoton(21)">+</button><button onclick="quitar(21, 37)">-</button><button onclick="Eliminar(21, 37)">eliminar</button><hr></li>', '');
    cantidad21 = 0;
    }
    else {
      cantidad21 = cantidad21 - 1;
      document.getElementById("cantidad21").innerHTML = cantidad21;
     }
}else if (identificación === 22) {
      
  if  (cantidad22 === 1) {
      cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/teclado2.JPG" alt="teclado inalambrico" width="200" height="150" class="original"><p class="textocesta">-Trust Nado<br><b>Precio:29€</b></p>x<span id="cantidad22">1</span><br><button onclick="clickearOtroBoton(22)">+</button><button onclick="quitar(22, 29)">-</button><button onclick="Eliminar(22, 29)">eliminar</button><hr></li>', '');
    cantidad22 = 0;
    }
    else {
      cantidad22 = cantidad22 - 1;
      document.getElementById("cantidad22").innerHTML = cantidad22;
     }
}else if (identificación === 23) {
      
  if  (cantidad23 === 1) {
      cc.innerHTML = cc.innerHTML.replace('<li><img ="../imagenes/raton1.JPG" alt="raton cable" width="200" height="150" class="original1"><p class="textocesta">-Steelseries Rival 3 Ratón Óptico Gaming 8500DPI<br><b>Precio:33€</b></p>x<span id="cantidad23">1</span><br><button onclick="clickearOtroBoton(23)">+</button><button onclick="quitar(23, 33)">-</button><button onclick="Eliminar(23, 33)">eliminar</button><hr></li>', '');
    cantidad23 = 0;
    }
    else {
      cantidad23 = cantidad23 - 1;
      document.getElementById("cantidad23").innerHTML = cantidad23;
     }
}else if (identificación === 24) {
      
  if  (cantidad24 === 1) {
      cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/altavoz1.JPG" alt="altavoz" width="200" class="original1"><p class="textocesta">-Trust GXT 609 Zoxa Altavoces para PC RGB 12W<br><b>Precio:31€</b></p>x<span id="cantidad24">1</span><br><button onclick="clickearOtroBoton(24)">+</button><button onclick="quitar(24, 31)">-</button><button onclick="Eliminar(24, 31)">eliminar</button><hr></li>', '');
    cantidad24 = 0;
    }
    else {
      cantidad24 = cantidad24 - 1;
      document.getElementById("cantidad24").innerHTML = cantidad24;
     }
}else if (identificación === 25) {
      
  if  (cantidad25 === 1) {
      cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/disco1.JPG" alt="disco1" width="200" height="150" class="original1"><p class="textocesta ">-Aisens ASM2-RGB012<br><b>Precio:17€</b></p>x<span id="cantidad25">1</span><br><button onclick="clickearOtroBoton(25)">+</button><button onclick="quitar(25, 17)">-</button><button onclick="Eliminar(25, 17)">eliminar</button><hr></li>', '');
    cantidad25 = 0;
    }
    else {
      cantidad25 = cantidad25 - 1;
      document.getElementById("cantidad25").innerHTML = cantidad25;
     }
}else if (identificación === 26) {
      
  if  (cantidad26 === 1) {
      cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/disco2.JPG" alt="disco2" width="200" height="150" class="original"><p class="textocesta">-Dahua Technology C800A 2.5<br><b>Precio:69€</b></p>x<span id="cantidad26">1</span><br><button onclick="clickearOtroBoton(26)">+</button><button onclick="quitar(26, 69)">-</button><button onclick="Eliminar(26, 69)">eliminar</button><hr></li>', '');
    cantidad26 = 0;
    }
    else {
      cantidad26 = cantidad26 - 1;
      document.getElementById("cantidad26").innerHTML = cantidad26;
     }
}else if (identificación === 27) {
      
  if  (cantidad27 === 1) {
      cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/disco3.JPG" alt="disco3" width="200" height="150" class="original1"><p class="textocesta">-Aisens ASUC-M2D012-GR Dock<br><b>Precio:34€</b></p>x<span id="cantidad27">1</span><br><button onclick="clickearOtroBoton(27)">+</button><button onclick="quitar(27, 34)">-</button><button onclick="Eliminar(27, 34)">eliminar</button><hr></li>', '');
    cantidad27 = 0;
    }
    else {
      cantidad27 = cantidad27 - 1;
      document.getElementById("cantidad27").innerHTML = cantidad27;
     }
}else if (identificación === 28) {
      
  if  (cantidad28 === 1) {
      cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/disco4.JPG" alt="Samsung T7 Shield" width="200" height="150" class="original"><p class="textocesta">-Samsung T7 Shield<br><b>Precio:129€</b></p>x<span id="cantidad28">1</span><br><button onclick="clickearOtroBoton(28)">+</button><button onclick="quitar(28, 129)">-</button><button onclick="Eliminar(28, 129)">eliminar</button><hr></li>', '');
    cantidad28 = 0;
    }
    else {
      cantidad28 = cantidad28 - 1;
      document.getElementById("cantidad28").innerHTML = cantidad28;
     }
}
total2(preciototal);
actaulizarprecio();
}


//FUNCION PARA ELIMINAR EL PRODUCTO DIRECTAMENTE
  function Eliminar(identificación, precio){// para que funcione la funcion se necesesita una identificación del producto y el precio
    var cc = document.getElementById("contenidocesta");
    let cantidadcesta = document.getElementById('cantidadcesta');//  variable cantidad
  if(identificación === 1) { //Verifica si la identificación es igual a 1.
    preciototal = preciototal - (precio * cantidad1)//Si la identificación es 1, resta el precio del producto del precio total.
    preciototal1 = preciototal - (precio * cantidad1)//Si la identificación es 1, resta el precio del producto del precio total.
    cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/pc1.JPG" alt="Lenovo torre PC LOQ3 i5 RTX-4060" width="200" height="150" class="original1"><p class="textocesta">-Lenovo torre PC LOQ3 i5 RTX-4060<br><b>Precio:600€</b></p>x<span id="cantidad1">' + cantidad1 + '</span><br><button onclick="clickearOtroBoton(1)">+</button><button onclick="quitar(1, 600)">-</button><button onclick="Eliminar(1, 600)">eliminar</button><hr></li>', '');
    cantidad.innerHTML = cantidad.innerHTML - cantidad1 //Resta la cantidad del producto eliminado del total de cantidad de productos.
    cantidadcesta.innerHTML = cantidadcesta.innerHTML - cantidad1 
    cantidad1 = 0;//Restablece la cantidad del producto con identificación 1 a 0.
  }else if(identificación === 2) {
    preciototal = preciototal - (precio * cantidad2)
    preciototal1 = preciototal - (precio * cantidad2)
    cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/pc3.JPG" alt="HP Pavilion TP01-4004ns Intel Core i5-13400/16GB/1TB+512GB SSD" width="100" height="150" class="original1"><p class="textocesta">-HP Pavilion TP01-4004ns Intel Core i5-13400/16GB/1TB+512GB SSD<br><b>Precio: 400€</b></p>x<span id="cantidad2">'+ cantidad2 +'</span><br><button onclick="clickearOtroBoton(2)">+</button><button onclick="quitar(2, 400)">-</button><button onclick="Eliminar(2, 400)">eliminar</button><hr></li>', '');
    cantidad.innerHTML = cantidad.innerHTML - cantidad2
    cantidadcesta.innerHTML = cantidadcesta.innerHTML - cantidad2 
    cantidad2 = 0;
  }else if(identificación === 3) {
    preciototal = preciototal - (precio * cantidad3)
    cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/pc4.JPG" alt="HP Slim Desktop S01-pF2027ns Intel Core i5-12400/8GB/256GB SSD" width="100" height="150" class="original1"><p class="textocesta">-HP Slim Desktop S01-pF2027ns Intel Core i5-12400/8GB/256GB SSD<br><b>Precio:459€</b></p>x<span id="cantidad3">'+ cantidad3+'</span><br><button onclick="clickearOtroBoton(3)">+</button><button onclick="quitar(3, 459)">-</button><button onclick="Eliminar(3, 459)">eliminar</button><hr></li>', '');
    cantidad.innerHTML = cantidad.innerHTML - cantidad3
    cantidad3 = 0;
  }else if(identificación === 4) {
    preciototal = preciototal - (precio * cantidad4)
    cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/pc5.JPG" alt="HP EliteDesk 800 G5 SFF Intel Core i5-9500/8GB/256GB SSD" width="200" height="150" class="original"><p class="textocesta">-HP EliteDesk 800 G5 SFF Intel Core i5-9500/8GB/256GB SSD<br><b>Precio:400€</b></p>x<span id="cantidad4">'+ cantidad4+'</span><br><button onclick="clickearOtroBoton(4)">+</button><button onclick="quitar(4, 400)">-</button><button onclick="Eliminar(4, 400)">eliminar</button><hr></li>', '');
    cantidad.innerHTML = cantidad.innerHTML - cantidad4
    cantidad4 = 0;
  }else if(identificación === 5) {
    preciototal = preciototal - (precio * cantidad5)
    cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/pc6.JPG" alt="HP Victus 15L TG02-0021ns AMD Ryzen 7 5700G/16GB/1TB+512GB SSD/RTX 3060" width="200" height="150" class="original1"><p class="textocesta">-HP Victus 15L TG02-0021ns AMD Ryzen 7 5700G/16GB/1TB+512GB SSD/RTX 3060<br><b>Precio:650€</b></p>x<span id="cantidad5">'+ cantidad5 +'</span><br><button onclick="clickearOtroBoton(5)">+</button><button onclick="quitar(5, 650)">-</button><button onclick="Eliminar(5, 650)">eliminar</button><hr></li>', '');
    cantidad.innerHTML = cantidad.innerHTML - cantidad5
    cantidad5 = 0;
  }else if(identificación === 6) {
    preciototal = preciototal - (precio * cantidad6)
    cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/pc7.JPG" alt="HP Pro Tower 400 G9 Intel Core i5-12500/16GB/512GB SSD" width="100" height="150" class="original1"><p class="textocesta">-HP Pro Tower 400 G9 Intel Core i5-12500/16GB/512GB SSD<br><b>Precio:669€</b></p>x<span id="cantidad6">'+ cantidad6 +'</span><br><button onclick="clickearOtroBoton(6)">+</button><button onclick="quitar(6, 669)">-</button><button onclick="Eliminar(6, 669)">eliminar</button><hr></li>', '');
    cantidad.innerHTML = cantidad.innerHTML - cantidad6
    cantidad6 = 0;
  }else if(identificación === 7) {
    preciototal = preciototal - (precio * cantidad7)
    cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/pc8.JPG" alt="HP Z6 G4 Intel Xeon Silver 4112/16GB/512GB SSD/Quadro P2000" width="100" height="150" class="original1"><p class="textocesta">-HP Pro Tower 400 G9 Intel Core i5-12500/16GB/512GB SSD<br><b>Precio:783€</b></p>x<span id="cantidad7">'+ cantidad7 +'</span><br><button onclick="clickearOtroBoton(7)">+</button><button onclick="quitar(7, 783)">-</button><button onclick="Eliminar(7, 783)">eliminar</button><hr></li>', '');
    cantidad.innerHTML = cantidad.innerHTML - cantidad7
    cantidad7 = 0;
  }else if(identificación === 8) {
    preciototal = preciototal - (precio * cantidad8)
    cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/pc9.JPG" alt="HP Pavilion Desktop TP01-4006ns Intel Core i5-13400/16GB/512GB SSD" width="200" height="150" class="original1"><p class="textocesta">-HP Pavilion Desktop TP01-4006ns Intel Core i5-13400/16GB/512GB SSD<br><b>Precio:749€</b></p>x<span id="cantidad8">'+ cantidad8 +'</span><br><button onclick="clickearOtroBoton(8)">+</button><button onclick="quitar(8, 749)">-</button><button onclick="Eliminar(8, 749)">eliminar</button><hr></li>', '');
    cantidad.innerHTML = cantidad.innerHTML - cantidad8
    cantidad8 = 0;
  }else if(identificación === 9) {
    preciototal = preciototal - (precio * cantidad9)
    cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/pc10.JPG" alt="HP 290 MT Sobremesa Intel Core i3-10110U/8GB/256GB SSD" width="200" height="150" class="original1"><p class="textocesta">-HP 290 MT Sobremesa Intel Core i3-10110U/8GB/256GB SSD<br><b>Precio:500€</b></p>x<span id="cantidad9">'+ cantidad9 +'</span><br><button onclick="clickearOtroBoton(9)">+</button><button onclick="quitar(9, 500)">-</button><button onclick="Eliminar(9, 500)">eliminar</button><hr></li>', '');
    cantidad.innerHTML = cantidad.innerHTML - cantidad9
    cantidad9 = 0;
  }else if(identificación === 10) {
    preciototal = preciototal - (precio * cantidad10)
    cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/pc11.JPG" alt="Iggual Psipch603 Intel Core i5-10400/8GB/480GB SSD" width="100" height="150" class="original1"><p class="textocesta">-Iggual Psipch603 Intel Core i5-10400/8GB/480GB SSD<br><b>Precio:390€</b></p>x<span id="cantidad10">'+ cantidad10 +'</span><br><button onclick="clickearOtroBoton(10)">+</button><button onclick="quitar(10, 390)">-</button><button onclick="Eliminar(10, 390)">eliminar</button><hr></li>', '');
    cantidad.innerHTML = cantidad.innerHTML - cantidad10
    cantidad10 = 0;
  }else if(identificación === 11) {
    preciototal = preciototal - (precio * cantidad11)
    cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/pc12.JPG" alt="Lenovo IdeaCentre 3 07ACH7 AMD Ryzen 5 5600H/8GB/512GB SSD" width="100" height="150" class="original1"><p class="textocesta">-Lenovo IdeaCentre 3 07ACH7 AMD Ryzen 5 5600H/8GB/512GB SSD<br><b>Precio:480€</b></p>x<span id="cantidad11">'+ cantidad11 +'</span><br><button onclick="clickearOtroBoton(11)">+</button><button onclick="quitar(11, 480)">-</button><button onclick="Eliminar(11, 480)">eliminar</button><hr></li>', '');
    cantidad.innerHTML = cantidad.innerHTML - cantidad11
    cantidad11 = 0;
  }else if(identificación === 12) {
    preciototal = preciototal - (precio * cantidad12)
    cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/pc13.JPG" alt="PcCom Work AMD Ryzen 7 5700G/16GB/500GB SSD" width="200" height="150" class="original1"><p class="textocesta">-PcCom Work AMD Ryzen 7 5700G/16GB/500GB SSD<br><b>Precio:480€</b></p>x<span id="cantidad12">'+ cantidad12 +'</span><br><button onclick="clickearOtroBoton(12)">+</button><button onclick="quitar(12, 605)">-</button><button onclick="Eliminar(12, 605)">eliminar</button><hr></li>', '');
    cantidad.innerHTML = cantidad.innerHTML - cantidad12
    cantidad12 = 0;
  }else if(identificación === 13) {
    preciototal = preciototal - (precio * cantidad13)
    cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/movil1.JPG" alt="Iphone 15 pro" width="200" height="150" class="original1"><p class="textocesta">-IPHONE 15 PRO<br><b>Precio:1219€</b></p>x<span id="cantidad13">'+ cantidad13 +'</span><br><button onclick="clickearOtroBoton(13)">+</button><button onclick="quitar(13, 1219)">-</button><button onclick="Eliminar(13, 1219)">eliminar</button><hr></li>', '');
    cantidad.innerHTML = cantidad.innerHTML - cantidad13
    cantidad13 = 0;
  }else if(identificación === 14) {
    preciototal = preciototal - (precio * cantidad14)
    cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/movil2.JPG" alt="Iphone 14" width="200" height="150" class="original1"><p class="textocesta">-IPHONE 14<br><b>Precio:859€</b></p>x<span id="cantidad14">'+ cantidad14 +'</span><br><button onclick="clickearOtroBoton(14)">+</button><button onclick="quitar(14, 859)">-</button><button onclick="Eliminar(14, 859)">eliminar</button><hr></li>', '');
    cantidad.innerHTML = cantidad.innerHTML - cantidad14
    cantidad14 = 0;
  }else if(identificación === 15) {
    preciototal = preciototal - (precio * cantidad15)
    cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/movil3.JPG" alt="Iphone 13 pro" width="200" height="150" id="movil31" class="original1"><p class="textocesta">-IPHONE 13 PRO<br><b>Precio:732€</b></p>x<span id="cantidad15">'+ cantidad15 +'</span><br><button onclick="clickearOtroBoton(15)">+</button><button onclick="quitar(15, 732)">-</button><button onclick="Eliminar(15, 732)">eliminar</button><hr></li>', '');
    cantidad.innerHTML = cantidad.innerHTML - cantidad15
    cantidad15 = 0;
  }else if(identificación === 16) {
    preciototal = preciototal - (precio * cantidad16)
    cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/movil4.JPG" alt="IPHONE 12 PRO MAX" width="200" height="150" class="original1"><p class="textocesta">-IPHONE 12 PRO MAX<br><b>Precio:573€</b></p>x<span id="cantidad16">'+ cantidad16 +'</span><br><button onclick="clickearOtroBoton(16)">+</button><button onclick="quitar(16, 573)">-</button><button onclick="Eliminar(16, 573)">eliminar</button><hr></li>', '');
    cantidad.innerHTML = cantidad.innerHTML - cantidad16
    cantidad16 = 0;
  }else if(identificación === 17) {
    preciototal = preciototal - (precio * cantidad17)
    cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/movil5.JPG" alt="REALME 10" width="200" height="150" class="original1"><p class="textocesta">-REALME 10<br><b>Precio:200€</b></p>x<span id="cantidad17">'+ cantidad17 +'</span><br><button onclick="clickearOtroBoton(17)">+</button><button onclick="quitar(17, 200)">-</button><button onclick="Eliminar(17, 200)">eliminar</button><hr></li>', '');
    cantidad.innerHTML = cantidad.innerHTML - cantidad17
    cantidad17 = 0;
  }else if(identificación === 18) {
    preciototal = preciototal - (precio * cantidad18)
    cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/movil6.JPG" alt="Huawei Nova 5T" width="100" height="150" class="original1"><p class="textocesta">-HUAWEY NOVA 5T<br><b>Precio:459€</b></p>x<span id="cantidad18">'+ cantidad18 +'</span><br><button onclick="clickearOtroBoton(18)">+</button><button onclick="quitar(18, 459)">-</button><button onclick="Eliminar(18, 459)">eliminar</button><hr></li>', '');
    cantidad.innerHTML = cantidad.innerHTML - cantidad18
    cantidad18 = 0;
  }else if(identificación === 19) {
    preciototal = preciototal - (precio * cantidad19)
    cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/movil7.JPG" alt="Smartphone Xiaomi Redmi Note 12 Pro" width="200" height="150" class="original1"><p class="textocesta">-Smartphone Xiaomi Redmi Note 12 Pro<br><b>Precio:279€</b></p>x<span id="cantidad19">'+ cantidad19 +'</span><br><button onclick="clickearOtroBoton(19)">+</button><button onclick="quitar(19, 279)">-</button><button onclick="Eliminar(19, 279)">eliminar</button><hr></li>', '');
    cantidad.innerHTML = cantidad.innerHTML - cantidad19
    cantidad19 = 0;
  }else if(identificación === 20) {
    preciototal = preciototal - (precio * cantidad20)
    cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/movil8.JPG" alt="GOOGLE PIXEL 8 PRO" width="200" height="150" class="original1"><p class="textocesta">-GOOGLE PIXEL 8 PRO<br><b>Precio:1159€</b></p>x<span id="cantidad20">'+ cantidad20 +'</span><br><button onclick="clickearOtroBoton(20)">+</button><button onclick="quitar(20, 1159)">-</button><button onclick="Eliminar(20, 1159)">eliminar</button><hr></li>', '');
    cantidad.innerHTML = cantidad.innerHTML - cantidad20
    cantidad20 = 0;
  }else if(identificación === 21) {
    preciototal = preciototal - (precio * cantidad21)
    cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/teclado1.JPG" alt="teclado cable" width="200" height="150" class="original"><p class="textocesta">-Tempest K11 Ogre<br><b>Precio:37€</b></p>x<span id="cantidad21">'+ cantidad21 +'</span><br><button onclick="clickearOtroBoton(21)">+</button><button onclick="quitar(21, 37)">-</button><button onclick="Eliminar(21, 37)">eliminar</button><hr></li>', '');
    cantidad.innerHTML = cantidad.innerHTML - cantidad21
    cantidad21 = 0;
  }else if(identificación === 22) {
    preciototal = preciototal - (precio * cantidad22)
    cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/teclado2.JPG" alt="teclado inalambrico" width="200" height="150" class="original"><p class="textocesta">-Trust Nado<br><b>Precio:29€</b></p>x<span id="cantidad22">'+ cantidad22 +'</span><br><button onclick="clickearOtroBoton(22)">+</button><button onclick="quitar(22, 29)">-</button><button onclick="Eliminar(22, 29)">eliminar</button><hr></li>', '');
    cantidad.innerHTML = cantidad.innerHTML - cantidad22
    cantidad22 = 0;
  }else if(identificación === 23) {
    preciototal = preciototal - (precio * cantidad23)
    cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/raton1.JPG" alt="raton cable" width="200" height="150" class="original1"><p class="textocesta">-Steelseries Rival 3 Ratón Óptico Gaming 8500DPI<br><b>Precio:33€</b></p>x<span id="cantidad23">'+ cantidad23 +'</span><br><button onclick="clickearOtroBoton(23)">+</button><button onclick="quitar(23, 33)">-</button><button onclick="Eliminar(23, 33)">eliminar</button><hr></li>', '');
    cantidad.innerHTML = cantidad.innerHTML - cantidad23
    cantidad23 = 0;
  }else if(identificación === 24) {
    preciototal = preciototal - (precio * cantidad24)
    cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/altavoz1.JPG" alt="altavoz" width="200" class="original1"><p class="textocesta">-Trust GXT 609 Zoxa Altavoces para PC RGB 12W<br><b>Precio:31€</b></p>x<span id="cantidad24">'+ cantidad24 +'</span><br><button onclick="clickearOtroBoton(24)">+</button><button onclick="quitar(24, 31)">-</button><button onclick="Eliminar(24, 31)">eliminar</button><hr></li>', '');
    cantidad.innerHTML = cantidad.innerHTML - cantidad24
    cantidad24 = 0;
  }else if(identificación === 25) {
    preciototal = preciototal - (precio * cantidad25)
    cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/disco1.JPG" alt="disco1" width="200" height="150" class="original1"><p class="textocesta ">-Aisens ASM2-RGB012<br><b>Precio:17€</b></p>x<span id="cantidad25">'+ cantidad25 +'</span><br><button onclick="clickearOtroBoton(25)">+</button><button onclick="quitar(25, 17)">-</button><button onclick="Eliminar(25, 17)">eliminar</button><hr></li>', '');
    cantidad.innerHTML = cantidad.innerHTML - cantidad25
    cantidad25 = 0;
  }else if(identificación === 26) {
    preciototal = preciototal - (precio * cantidad26)
    cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/disco2.JPG" alt="disco2" width="200" height="150" class="original"><p class="textocesta">-Dahua Technology C800A 2.5<br><b>Precio:69€</b></p>x<span id="cantidad26">'+ cantidad26 +'</span><br><button onclick="clickearOtroBoton(26)">+</button><button onclick="quitar(26, 69)">-</button><button onclick="Eliminar(26, 69)">eliminar</button><hr></li>', '');
    cantidad.innerHTML = cantidad.innerHTML - cantidad26
    cantidad26 = 0;
  }else if(identificación === 27) {
    preciototal = preciototal - (precio * cantidad27)
    cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/disco3.JPG" alt="disco3" width="200" height="150" class="original1"><p class="textocesta">-Aisens ASUC-M2D012-GR Dock<br><b>Precio:34€</b></p>x<span id="cantidad27">'+ cantidad27 +'</span><br><button onclick="clickearOtroBoton(27)">+</button><button onclick="quitar(27, 34)">-</button><button onclick="Eliminar(27, 34)">eliminar</button><hr></li>', '');
    cantidad.innerHTML = cantidad.innerHTML - cantidad27
    cantidad27 = 0;
  }else if(identificación === 28) {
    preciototal = preciototal - (precio * cantidad28)
    cc.innerHTML = cc.innerHTML.replace('<li><img src="../imagenes/disco4.JPG" alt="Samsung T7 Shield" width="200" height="150" class="original"><p class="textocesta">-Samsung T7 Shield<br><b>Precio:129€</b></p>x<span id="cantidad28">'+ cantidad28 +'</span><br><button onclick="clickearOtroBoton(28)">+</button><button onclick="quitar(28, 129)">-</button><button onclick="Eliminar(28, 129)">eliminar</button><hr></li>', '');
    cantidad.innerHTML = cantidad.innerHTML - cantidad28
    cantidad28 = 0;
  }
  total2(preciototal);
  actaulizarprecio();
  }

//Funcion para actualizar
function actaulizarprecio() {
  let preciot = document.getElementById('totalp')
  preciot.innerHTML = preciototal
  let preciot1 = document.getElementById('totalp1')
  preciot1.innerHTML = preciototal
  let cantidadcesta = document.getElementById('cantidadcesta')
  cantidadcesta.innerText = parseInt(cantidad.innerText);
}

//DESCUENTOS

var ultimaPalabraValidada = null;

function validarPalabra() {
    // Obtener el valor del input
    var palabra = document.getElementById("texto").value.toLowerCase();

    // Verificar si la palabra actual es igual a la última palabra validada
    if (palabra === ultimaPalabraValidada) {
        alert("¡Ya has usado este código!");
        return false;
    }

    // Palabra que queremos validar
    var palabraValida = "manuel25";
  
    // Definir el descuento
    var descuento1 = preciototal * 0.25;

    // Comparamos la palabra ingresada con la palabra válida
    if (palabra === palabraValida) {
        alert('Se ha aplicado un descuento del 25%');
        preciototal = preciototal - descuento1;
        // Agregar texto en la cesta indicando el descuento
        var cestaDescuento = document.getElementById("textoDescuento");
        cestaDescuento.innerText = "Descuento del 25% aplicado";
        // Actualizar la última palabra validada
        ultimaPalabraValidada = palabra;
    } else {
        alert("El código no es correcto");
        return false;
    }
    total2(preciototal);
    actaulizarprecio();
}

//Función para cambiar la imagen al pasar por encima 
function cambiarImagen(id, nuevaImagen){
  if (id === "pc1") {
    document.getElementById("pc1").src = nuevaImagen;
  } else if (id === "pc2") {
    document.getElementById("pc2").src = nuevaImagen;
  }else if (id === "pc3") {
    document.getElementById("pc3").src = nuevaImagen;
  }else if (id === "pc4") {
    document.getElementById("pc4").src = nuevaImagen;
  }else if (id === "pc5") {
    document.getElementById("pc5").src = nuevaImagen;
  }else if (id === "pc6") {
    document.getElementById("pc6").src = nuevaImagen;
  }else if (id === "pc7") {
    document.getElementById("pc7").src = nuevaImagen;
  }else if (id === "pc8") {
    document.getElementById("pc8").src = nuevaImagen;
  }else if (id === "pc9") {
    document.getElementById("pc9").src = nuevaImagen;
  }else if (id === "pc10") {
    document.getElementById("pc10").src = nuevaImagen;
  }else if (id === "pc11") {
    document.getElementById("pc11").src = nuevaImagen;
  }else if (id === "pc12") {
    document.getElementById("pc12").src = nuevaImagen;
  }else if (id === "pc13") {
    document.getElementById("pc13").src = nuevaImagen;
  }else if (id === "movil1") {
    document.getElementById("movil1").src = nuevaImagen;
  }else if (id === "movil2") {
    document.getElementById("movil2").src = nuevaImagen;
  }else if (id === "movil3") {
    document.getElementById("movil3").src = nuevaImagen;
  }else if (id === "movil4") {
    document.getElementById("movil4").src = nuevaImagen;
  }else if (id === "movil5") {
    document.getElementById("movil5").src = nuevaImagen;
  }else if (id === "movil6") {
    document.getElementById("movil6").src = nuevaImagen;
  }else if (id === "movil7") {
    document.getElementById("movil7").src = nuevaImagen;
  }else if (id === "movil8") {
    document.getElementById("movil8").src =nuevaImagen;
  }else if (id === "teclado1") {
    document.getElementById("teclado1").src =nuevaImagen;
  }else if (id === "teclado2") {
    document.getElementById("teclado2").src =nuevaImagen;
  } else if (id === "raton1") {
    document.getElementById("raton1").src =nuevaImagen;
  }else if (id === "altavoz1") {
    document.getElementById("altavoz1").src =nuevaImagen;
  }else if (id === "disco1") {
    document.getElementById("disco1").src =nuevaImagen;
  }else if (id === "disco2") {
    document.getElementById("disco2").src =nuevaImagen;
  } else if (id === "disco3") {
    document.getElementById("disco3").src =nuevaImagen;
  }else if (id === "disco4") {
    document.getElementById("disco4").src =nuevaImagen;
  }                                            
}

// Función para restaurar la imagen original cuando el mouse sale de la imagen
function restaurarImagen(id, imagenOriginal) {
  if (id === "pc1") {
    document.getElementById("pc1").src = imagenOriginal;
  } else if (id === "pc2") {
    document.getElementById("pc2").src = imagenOriginal;
  }else if (id === "pc3") {
    document.getElementById("pc3").src = imagenOriginal;
  }else if (id === "pc4") {
    document.getElementById("pc4").src = imagenOriginal;
  }else if (id === "pc5") {
    document.getElementById("pc5").src = imagenOriginal;
  }else if (id === "pc6") {
    document.getElementById("pc6").src = imagenOriginal;
  }else if (id === "pc7") {
    document.getElementById("pc7").src = imagenOriginal;
  }else if (id === "pc8") {
    document.getElementById("pc8").src = imagenOriginal;
  }else if (id === "pc9") {
    document.getElementById("pc9").src = imagenOriginal;
  }else if (id === "pc10") {
    document.getElementById("pc10").src = imagenOriginal;
  }else if (id === "pc11") {
    document.getElementById("pc11").src = imagenOriginal;
  }else if (id === "pc12") {
    document.getElementById("pc12").src = imagenOriginal;
  }else if (id === "pc13") {
    document.getElementById("pc13").src = imagenOriginal;
  }else if (id === "movil1") {
    document.getElementById("movil1").src = imagenOriginal;
  }else if (id === "movil2") {
    document.getElementById("movil2").src = imagenOriginal;
  }else if (id === "movil3") {
    document.getElementById("movil3").src = imagenOriginal;
  }else if (id === "movil4") {
    document.getElementById("movil4").src = imagenOriginal;
  }else if (id === "movil5") {
    document.getElementById("movil5").src = imagenOriginal;
  }else if (id === "movil6") {
    document.getElementById("movil6").src = imagenOriginal;
  }else if (id === "movil7") {
    document.getElementById("movil7").src = imagenOriginal;
  }else if (id === "movil8") {
    document.getElementById("movil8").src = imagenOriginal;
  }else if (id === "teclado1") {
    document.getElementById("teclado1").src = imagenOriginal;
  }else if (id === "teclado2") {
    document.getElementById("teclado2").src = imagenOriginal;
  } else if (id === "raton1") {
    document.getElementById("raton1").src = imagenOriginal;
  }else if (id === "altavoz1") {
    document.getElementById("altavoz1").src = imagenOriginal;
  }else if (id === "disco1") {
    document.getElementById("disco1").src =imagenOriginal;
  }else if (id === "disco2") {
    document.getElementById("disco2").src =imagenOriginal;
  } else if (id === "disco3") {
    document.getElementById("disco3").src =imagenOriginal;
  }else if (id === "disco4") {
    document.getElementById("disco4").src =imagenOriginal;
  }                                  
}
    //BUSCAR PRODUCTO
    
  function goToSearch() {
    var searchText = document.getElementById("search-box").value.trim().toLowerCase(); // Obtener el texto de búsqueda y eliminar espacios en blanco
    var productos = document.getElementsByClassName("producto");

    // Verificar si se ingresó texto en el campo de búsqueda
    if (searchText !== "") {
        for (var i = 0; i < productos.length; i++) {
            var productoText = productos[i].innerText.toLowerCase();

            if (productoText.includes(searchText)) {
                // Hacer scroll hasta el producto que coincide con la búsqueda
                productos[i].scrollIntoView({ 
                    behavior: 'smooth',
                    block: 'start'
                });

                // Resaltar el producto cambiando su fondo
                productos[i].style.backgroundColor = "orange";

                // Salir del bucle una vez encontrado el producto
                break;
            } else {
                // Restaurar el fondo de los productos que no coinciden con la búsqueda
                productos[i].style.backgroundColor = "initial";
            }
        }
    } else {
        // Si no se ingresó texto, no hacer nada
        return;
    }
}

// INICIAR SESIÓN

// Función para abrir la ventana de iniciar sesión
function abrirVentana() {
  document.getElementById("miVentana").style.display = "block";
}

// Función para cerrar la ventana de iniciar sesión
function cerrarVentana() {
  document.getElementById("miVentana").style.display = "none";
  return false; // Evita el comportamiento predeterminado de un formulario (si lo hay) al hacer clic en el botón de cerrar
}

//ABRIR FORMULARIO DE LA CESTA

// Función para abrir el formulario de la cesta
  function abrirVentana1() {
    var ccc = parseInt(document.getElementById("cantidad").innerText); // Obtener la cantidad de productos en la cesta
    if (ccc > 0) {
      // Si hay al menos un producto en la cesta, mostrar la ventana de formulario
      alert("Debes de rellenar el siguiente formulario para proceder al pago");
      document.getElementById("miVentana1").style.display = "block";
    } else {
      // Si la cesta está vacía, mostrar un mensaje de que se deben agregar productos
      alert("La cesta está vacía. Añade productos para proceder al pago.");
    }
  } 
// Función para cerrar la ventana del formulario
function cerrarVentana1() {
  document.getElementById("miVentana1").style.display = "none";
}

//CREDENCIALES INICAR SESION
function validarCredenciales() {
  var usuario = document.getElementById("usuario").value;
  var contraseña = document.getElementById("contraseña").value;
  
  // Aquí debes colocar tus credenciales válidas
  var usuarioValido = "manuel";
  var contraseñaValida = "250805";

  if (usuario === usuarioValido && contraseña === contraseñaValida) {
      // Inicio de sesión exitoso, puedes redirigir a otra página o realizar otras acciones
      alert("Inicio de sesión exitoso!");
      document.getElementById("miVentana").style.display = "none"; // Cerrar la ventana de inicio de sesión
      return false; // Evitar el envío del formulario
  } else {
      // Credenciales incorrectas, mostrar mensaje de error
      alert("Usuario o contraseña erroneos")
      return false; // Evitar el envío del formulario
  }
}

//BOTON PARA VOLVER AL PRINCIPIO
function BOTON() {//  la función BOTON
  var boton1 = document.createElement('button');// variable boton1
  boton1.id = 'scroll-to-top'; // Asigna un id 'scroll-to-top' al botón
  boton1.innerHTML = '↑';// Establece el contenido del botón como una flecha hacia arriba (↑)
  boton1.onclick = function() {// Asigna una función al evento de clic del botón
      document.body.scrollTop = 0;// Hace que el cuerpo de la página vuelva al principio (para navegadores Safari)
      document.documentElement.scrollTop = 0;// Hace que el cuerpo de la página vuelva al principio (para otros navegadores)
  };
  document.body.appendChild(boton1);// Agrega el botón al final del cuerpo del documento
  window.onscroll = function() {// Asigna una función al evento de desplazamiento de la ventana y verifica si la posición de desplazamiento es mayor que 20 píxeles
      if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {// Si es mayor, muestra el botón
          boton1.style.display = 'block';
      } else {
          boton1.style.display = 'none';// Si no, oculta el botón
      }
  };
}
window.onload = BOTON;// hace que funcione en el html
